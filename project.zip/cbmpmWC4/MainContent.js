import React from "react"


export default function MainContent(){
    return(
      <div className="maincontent">
           <h1> Reasons i m excited to learn React </h1>
           <ol>
           <li> A popular library so i'll be able to fit in with the cool kids </li>
           <li>  Most likely to get a job if i know react </li>
           </ol>
     </div>
    )   
}